(function ($) {
	$(function () {
		$('.wp-color-picker').wpColorPicker();
	});
}(jQuery));