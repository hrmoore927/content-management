<?php
/**
 * @package WordPress
 * @subpackage Medicure
 * @since Medicure 1.4.0
 * 
 * Website Woocommerce Functions
 * Created by CMSMasters
 * 
 */


/* Woocommerce Dynamic Cart */

function cmsms_woocommerce_cart_dropdown() {
	global $woocommerce; 
	
	$cart_subtotal = $woocommerce->cart->get_cart_subtotal();
	$link = $woocommerce->cart->get_cart_url();

	
	$output = '';
	$output .= '<div class="cmsms_dynamic_cart">' .  
		'<a href="javascript:void(0);" class="cmsms_dynamic_cart_button icon-basket"></a>' . 
		'<div class="widget_shopping_cart_content"></div>' . 
	'</div>';

	echo $output;
}


/* Woocommerce Add to Cart Button */

function cmsms_woocommerce_add_to_cart_button() {
	global $product;
	
	echo '<div class="cmsms_prod_line">';
	
	if ($product->is_purchasable() && $product->product_type == 'simple' && $product->is_in_stock()) {
		echo '<a href="' . esc_url($product->add_to_cart_url()) . '" data-product_id="' . esc_attr($product->id) . '" data-product_sku="' . esc_attr($product->get_sku()) . '" class="add_to_cart_button cmsms_add_to_cart_button product_type_simple icon-basket">' . __('To Cart', 'cmsmasters') . '</a>';
	}
	
	echo '<span class="cmsms_prod_line_sep"></span><a href="' . get_permalink($product->id) . '" data-product_id="' . esc_attr($product->id) . '" data-product_sku="' . esc_attr($product->get_sku()) . '" class="cmsms_details_button icon-list-bullet">' . __('Details', 'cmsmasters') . '</a>' . 
	
	'</div>';
}


if (version_compare(WOOCOMMERCE_VERSION, '2.1') >= 0) {
	add_filter('woocommerce_enqueue_styles', '__return_false');
} else {
	define('WOOCOMMERCE_USE_CSS', false);
}


add_theme_support( 'woocommerce' );

