<?php
/**
 * Single Product Thumbnails
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.3
 * 
 * @cmsms_package 	Medicure
 * @cmsms_version 	1.4.0
 */


