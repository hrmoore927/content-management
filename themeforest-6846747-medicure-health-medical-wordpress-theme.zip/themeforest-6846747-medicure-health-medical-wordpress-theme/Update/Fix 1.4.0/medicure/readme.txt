/**
 * @package WordPress
 * @subpackage Medicure
 * @since Medicure 1.4.1
 * 
 * Theme Information
 * Created by CMSMasters
 * 
 */

Version 1.4.1
medicure/style.css
medicure/readme.txt
medicure/js/jquery.script.js
medicure/framework/class/class-tgm-plugin-activation.php
medicure/framework/admin/inc/plugin-activator.php
medicure/framework/admin/inc/plugins/LayerSlider.zip
medicure/framework/admin/inc/plugins/revslider.zip


Version 1.4.0

Files edited:

medicure/style.css
medicure/header.php
medicure/sidebar-bottom.php
medicure/sidebar-middle.php
medicure/sidebar-top.php
medicure/sidebar.php
medicure/footer.php
medicure/css/cmsms-woocommerce-style.css
medicure/css/fonts.php
medicure/framework/admin/inc/plugin-activator.php
medicure/framework/class/class-tgm-plugin-activation.php
medicure/framework/function/breadcrumbs.php
medicure/woocommerce/archive-product.php
medicure/woocommerce/checkout/thankyou.php
medicure/woocommerce/cmsms-woocommerce-functions.php
medicure/woocommerce/content-product.php
medicure/woocommerce/content-single-product.php
medicure/woocommerce/global/wrapper-end.php
medicure/woocommerce/global/wrapper-start.php
medicure/woocommerce/loop/rating.php
medicure/woocommerce/single-product.php
medicure/woocommerce/single-product/meta.php
medicure/woocommerce/single-product/product-image.php
medicure/woocommerce/single-product/product-thumbnails.php
medicure/woocommerce/single-product/review.php
medicure/woocommerce/single-product/tabs/additional-information.php
medicure/woocommerce/single-product/tabs/description.php

Files deleted:

woocommerce/cart/mini-cart.php
woocommerce/order/order-details.php
woocommerce/single-product/tabs/tabs.php


Version 1.3.1

Files edited:

medicure/style.css
medicure/adaptive.css
medicure/header.php
medicure/footer.php
medicure/theme-functions.php

Version 1.3.0

medicure/style.css
medicure/readme.txt
medicure/css/cmsms-woocommerce-style.css
medicure/css/fonts.php
medicure/css/retina.css
medicure/img/retina/star@2x.png
medicure/img/retina/star_bot@2x.png
medicure/img/star@2x.png
medicure/img/star_bot@2x.png
medicure/framework/admin/inc/plugins/cmsms-contact-form-builder.zip
medicure/framework/admin/inc/plugin-activator.php
medicure/framework/admin/settings/cmsms-theme-settings-general.php
medicure/header.php
medicure/woocommerce/single-product.php
medicure/js/jquery.script.js
medicure/framework/function/template-functions.php
medicure/framework/admin/options/cmsms-theme-options-service.php
medicure/framework/admin/settings/cmsms-theme-settings-services.php
medicure/framework/postType/services/post/album.php
medicure/framework/postType/services/post/slider.php
medicure/framework/postType/services/post/video.php



Version 1.2 - WOOCOMMERCE SUPPORT INCLUDED!


Files added:
medicure/woocommerce/
medicure/img/star.png
medicure/img/star_bot.png
medicure/img/retina/star@2x.png
medicure/img/retina/star_bot@2x.png
medicure/framework/admin/inc/plugins/
medicure/css/cmsms-woocommerce-style.css
medicure/js/jquery.cmsms-woocommerce-script.js
medicure/framework/admin/options/cmsms-theme-options-product.php

Files updated:
medicure/framework/admin/inc/plugin-activator.php
medicure/framework/admin/settings/cmsms-theme-settings-style.php
medicure/framework/admin/options/cmsms-theme-options.php
medicure/css/fonts.php
medicure/css/adaptive.css
medicure/css/retina.css
medicure/header.php
medicure/footer.php
medicure/framework/function/theme-functions.php
medicure/framework/function/breadcrumbs.php
medicure/functions.php
medicure/rtl.css
medicure/style.css
medicure/readme.txt
medicure/sidebar.php
medicure/sidebar-bottom.php
medicure/sidebar-middle.php
medicure/sidebar-top.php
medicure/framework/languages/medicure.pot





Version 1.1.1

medicure/style.css
medicure/readme.txt
medicure/framework/admin/composer/inc/post/composer_popup.php


Version 1.1 - Update  - for Wordpress 3.9

medicure/style.css
medicure/readme.txt
medicure/comments.php
medicure/framework/admin/composer/inc/box/composer_popup.php
medicure/framework/admin/composer/inc/person/composer_popup.php
medicure/framework/admin/composer/inc/tab/composer_popup.php
medicure/framework/admin/composer/inc/text/composer_popup.php


Version 1.0.7

medicure/style.css
medicure/readme.txt
medicure/css/fonts.php


Version 1.0.6

medicure/style.css
medicure/readme.txt
medicure/css/adaptive.css
medicure/css/fonts.php
medicure/js/jquery.script.js

Version 1.0.5

medicure/style.css
medicure/readme.txt
medicure/framework/admin/inc/plugins/LayerSlider.zip



Version 1.0.4

medicure/style.css
medicure/readme.txt
medicure/css/adaptive.css
medicure/header.php
medicure/css/fonts/css/fontello.css



Version 1.0.3

medicure/style.css
medicure/readme.txt
medicure/framework/function/theme-functions.php
medicure/img/bg.png


Version 1.0.2

medicure/style.css
medicure/readme.txt
medicure/css/fonts/icons.eot
medicure/css/fonts/icons.svg
medicure/css/fonts/icons.ttf
medicure/css/fonts/icons.woff


-------------------
IMPORTANT!!!

In version 1.0.2 we added a possibility to use Fontello icon font in your content.

You can use instructions in theme documentation to learn how to add specific icons to your website content and edit their appearance. Please see the DOCS folder in the archive you have downloaded from Themeforest and  open the index.html file with your browser. 
Reference section: Icons (Header, Social & Content), see the Content Icons part.

Also, you can view all the available icons if you open the demo.html file (ICONS folder in Themeforest archive) in your browser.
-------------------



Version 1.0.1

medicure/css/adaptive.css
medicure/style.css
medicure/readme.txt


Version 1.0: Release!
