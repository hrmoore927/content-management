




If you have downloaded Medicure theme for the first time, just use "medicure.zip"




To update your theme copy this folder to your server "wp-content/themes/" and replace existing files (see the readme file for the list of all the files that were updated).


------------------------WARNING!---------------------------------


To avoid issues with your current data we recommend to make a backup before updating.
Please disable your plugins before updating files.
