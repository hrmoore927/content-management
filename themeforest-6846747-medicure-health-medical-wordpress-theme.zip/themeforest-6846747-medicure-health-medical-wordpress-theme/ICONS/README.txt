IMPORTANT!!!

In version 1.0.2 we added a possibility to use Fontello icon font in your content.


You can view all the available icons if you open the demo.html file in your browser.

You can use instructions in theme documentation to learn how to add specific icons to your website content and edit their appearance. Please see the DOCS folder in the archive you have downloaded from Themeforest and  open the index.html file with your browser. 
Reference section: Icons (Header, Social & Content), see the Content Icons part.

