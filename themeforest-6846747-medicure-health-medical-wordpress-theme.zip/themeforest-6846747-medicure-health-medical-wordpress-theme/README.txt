
------------------------------------------------------------------
      BEFORE GETTING STARTED, PLEASE READ THIS CAREFULLY
------------------------------------------------------------------

There's a detailed documentation in the theme archive. 

You can easily setup your site using these "How to" instructions.

You'll find it in the following folder in the archive:
\DOCS\

Just open index.html file with your browser.


------------------------------------------------------------------
                         To install DEMO CONTENT 
                 please follow README instructions in 
                         /DEMO CONTENT/ folder.


                       To install plugins, 
                 please, follow our HOW-TO instructions in DOCS.
       See Medicure Theme Installation > Add Plugins chapter.


==================================================================
                         Docs chapters list
------------------------------------------------------------------

>> Medicure Theme Installation (NECESSARY TO READ)

>> Demo Content

>> Theme Colors & Fonts

>> Website Background

>> Header, Logo & Favicon

>> Footer

>> Icons

>> Menu Setup

>> Add Page & Home Page

>> Pages Setup

>> Blog & Posts Setup

>> Services Setup

>> Testimonials Setup

>> Options

>> Shortcodes & Composer

>> Widgets & Sidebars

>> Contact Forms

>> Slider Setup

>> Translate your website 



==================================================================
                   CMSMASTERS SUPPORT POLICY
------------------------------------------------------------------

            IF YOU NEED SUPPORT ON A PURCHASED ITEM
------------------------------------------------------------------

- Please, make sure that you've read our Docs/Readme instructions thoroughly.

- Read the support FAQ or submit a support question at the FORUM:
WP themes >> http://forums.cmsmasters.net/forumdisplay.php?3-Wordpress-Themes
HTML templates >> http://forums.cmsmasters.net/forumdisplay.php?7-Site-templates-%28HTML%29
Note: If you've registered at the forum and haven't received a confirmation email, please, send us your forum credentials and we'll confirm you manually.

- Try to deactivate plugins one by one to see which of them provokes the issue. We don't guarantee compatibility with ANY additional plugin except the ones that are included in the theme archive.

- We can't provide any help without purchase confirmation, so you should specify your Item Purchase Code in the support ticket. You can find the purchase code in this file at "Downloads" tab on your Envato account. See the screenshot >> http://docs.cmsmasters.net/wp-content/uploads/2014/01/purchase-code.png
Don't share your purchase code at the Support Forum due to security reasons.

- We don't provide personal support via comments on ThemeForest, all requests will be assigned on Zendesk using this form >> http://docs.cmsmasters.net

Please use Themeforest comments to ask only basic questions that do not require an extended answer or deep investigation.

ATTENTION:
Any submitted support questions which are covered by the forum FAQs or our docs CAN BE UNANSWERED without additional notifying from our side!
Also we are not responsible for tickets not been answered in the event of your negligence (i.e. wrong e-mail) or due to technical bugs and delivery failure.

It's beyond our support policy to provide help for the customers who modified our WP theme code.

------------------------------------------------------------------
                 IF YOU HAVE A PRESALE QUESTION
------------------------------------------------------------------

You may post it on the Item's comments page.

You can access our portfolios from these pages:
Themeforest >> http://themeforest.net/user/cmsmasters/portfolio


------------------------------------------------------------------
           IF YOUR QUESTION IS RELATED TO ANY OTHER MATTER
------------------------------------------------------------------

Please allow up to 2 working days (common issues) or 4 working days (problems which require developer's assistance) for your ticket or forum thread to be answered.
The cmsmasters support center works Monday to Friday.

Thank you for taking your time to read.



--
Best regards,
The cmsmasters team