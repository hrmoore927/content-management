﻿
To import Layer slider demo content, please, follow the steps below:




1 – Open “Layer Slider”



2 – Scroll down to find “Import slider” area



3 – Browse for the file included in Slider Demo Content folder

4 – Click “Import”



5 - You can apply changes to the slider according to your needs

