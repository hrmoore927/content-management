To import our Demo content you should install WordPress Importer plugin

http://wordpress.org/extend/plugins/wordpress-importer/

1 - Download it and upload on your server (wp-conten/plugins)

2 - Go to tools - Import

3 - Choose "Wordpress"

4 - Upload "medicuredemo.wordpress.2014-02-11.xml" (choose to import images if you want)

5 - Done!

Use the icons from the appropriate folder to make your site look like our demo.



